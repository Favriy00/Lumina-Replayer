# ✦ Lumina Replayer

Reproductor de música **local** para móvil, hecho con Flutter.
Tema oscuro, azul mágico (cian → azul eléctrico → violeta) y una estrella fugaz como logo.

## Funciones (v0.1)
- Escanea la música del dispositivo
- Búsqueda por título o artista
- Reproducir / pausar / siguiente / anterior
- Aleatorio y repetición (todo / una)
- Barra de progreso, mini-reproductor y pantalla "Reproduciendo ahora"
- Reproducción en segundo plano con controles en la notificación

## Instalación
```bash
flutter create --org com.lumina --project-name lumina_replayer .
# Copia estos archivos encima del proyecto (reemplaza los existentes)
flutter pub get
flutter run
```

## iOS
En `ios/Runner/Info.plist` agrega:
```xml
<key>NSAppleMusicUsageDescription</key>
<string>Lumina Replayer necesita acceder a tu música.</string>
<key>UIBackgroundModes</key>
<array><string>audio</string></array>
```
> En iOS solo se lee la música de la app Música (biblioteca sincronizada); no se puede escanear archivos sueltos.

## Si falla el build en Android con `on_audio_query`
Algunas versiones del plugin no declaran `namespace`. Abre su `build.gradle` en la caché de pub
(`~/.pub-cache/hosted/pub.dev/on_audio_query_android-*/android/build.gradle`) y dentro de `android { }` agrega:
```
namespace 'com.lucasjosino.on_audio_query'
```

## Estructura
```
lib/
  main.dart
  theme/lumina_theme.dart
  services/player_controller.dart
  screens/library_screen.dart
  screens/now_playing_screen.dart
  widgets/ (logo, fondo mágico, mini-reproductor, carátulas)
assets/logo.svg
```

## Próximos pasos
Listas de reproducción, favoritos, ecualizador, álbumes/artistas, temporizador de sueño, letras.
