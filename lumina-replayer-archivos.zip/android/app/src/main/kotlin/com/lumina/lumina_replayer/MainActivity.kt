package com.lumina.lumina_replayer

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
