import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';

import 'screens/library_screen.dart';
import 'services/player_controller.dart';
import 'theme/lumina_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.lumina.lumina_replayer.channel.audio',
    androidNotificationChannelName: 'Lumina Replayer',
    androidNotificationOngoing: true,
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Lumina.night,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(
    ChangeNotifierProvider(
      create: (_) => PlayerController()..init(),
      child: const LuminaApp(),
    ),
  );
}

class LuminaApp extends StatelessWidget {
  const LuminaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lumina Replayer',
      debugShowCheckedModeBanner: false,
      theme: Lumina.theme,
      darkTheme: Lumina.theme,
      themeMode: ThemeMode.dark,
      home: const LibraryScreen(),
    );
  }
}
