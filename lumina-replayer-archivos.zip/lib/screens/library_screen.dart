import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/player_controller.dart';
import '../theme/lumina_theme.dart';
import '../widgets/lumina_logo.dart';
import '../widgets/magic_background.dart';
import '../widgets/mini_player.dart';
import '../widgets/song_artwork.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final c = context.watch<PlayerController>();
    final list = _q.isEmpty
        ? c.songs
        : c.songs
            .where((s) =>
                s.title.toLowerCase().contains(_q) ||
                PlayerController.artistOf(s).toLowerCase().contains(_q))
            .toList();

    return Scaffold(
      body: MagicBackground(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                child: Row(
                  children: [
                    const LuminaLogo(size: 40),
                    const SizedBox(width: 10),
                    ShaderMask(
                      shaderCallback: (r) => Lumina.gradient.createShader(r),
                      child: const Text('Lumina Replayer',
                          style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                              letterSpacing: .5,
                              color: Colors.white)),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: TextField(
                  onChanged: (v) => setState(() => _q = v.trim().toLowerCase()),
                  decoration: InputDecoration(
                    hintText: 'Buscar canción o artista',
                    hintStyle: const TextStyle(color: Lumina.textLo),
                    prefixIcon: const Icon(Icons.search_rounded, color: Lumina.textLo),
                    filled: true,
                    fillColor: Lumina.surface,
                    contentPadding: const EdgeInsets.symmetric(vertical: 0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              Expanded(child: _body(context, c, list)),
              const MiniPlayer(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _body(BuildContext context, PlayerController c, List list) {
    if (c.loading) {
      return const Center(child: CircularProgressIndicator(color: Lumina.cyan));
    }
    if (c.permissionDenied) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline_rounded, size: 48, color: Lumina.azure),
              const SizedBox(height: 16),
              const Text('Necesito acceso a tu música para mostrarla aquí.',
                  textAlign: TextAlign.center),
              const SizedBox(height: 20),
              FilledButton(onPressed: c.init, child: const Text('Dar permiso')),
              TextButton(onPressed: c.openSettings, child: const Text('Abrir ajustes')),
            ],
          ),
        ),
      );
    }
    if (list.isEmpty) {
      return const Center(
        child: Text('No encontré música ✦', style: TextStyle(color: Lumina.textLo)),
      );
    }
    final currentId = c.current?.id;
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 8),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final s = list[i];
        final isCurrent = s.id == currentId;
        return ListTile(
          leading: SongArtwork(id: s.id),
          title: Text(s.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: isCurrent ? Lumina.cyan : Lumina.textHi)),
          subtitle: Text(PlayerController.artistOf(s),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Lumina.textLo)),
          trailing: isCurrent
              ? Icon(c.playing ? Icons.graphic_eq_rounded : Icons.pause_rounded,
                  color: Lumina.cyan)
              : null,
          onTap: () => c.playFrom(c.songs.indexOf(s)),
        );
      },
    );
  }
}
