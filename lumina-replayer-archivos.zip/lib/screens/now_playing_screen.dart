import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../services/player_controller.dart';
import '../theme/lumina_theme.dart';
import '../widgets/magic_background.dart';
import '../widgets/song_artwork.dart';

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<PlayerController>();
    final song = c.current;
    final width = MediaQuery.of(context).size.width;
    final art = (width - 64).clamp(200.0, 340.0).toDouble();

    return Scaffold(
      body: MagicBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
                    ),
                    const Expanded(
                      child: Text('Reproduciendo ahora',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Lumina.textLo, letterSpacing: 1)),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                const Spacer(),
                if (song != null) ...[
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                            color: Lumina.azure.withAlpha(110),
                            blurRadius: 50,
                            spreadRadius: 2),
                      ],
                    ),
                    child: SongArtwork(id: song.id, size: art, radius: 28),
                  ),
                  const SizedBox(height: 32),
                  Text(song.title,
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(PlayerController.artistOf(song),
                      style: const TextStyle(color: Lumina.textLo, fontSize: 15)),
                ],
                const SizedBox(height: 24),
                _SeekBar(player: c.player),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: c.toggleShuffle,
                      icon: Icon(Icons.shuffle_rounded,
                          color: c.shuffle ? Lumina.cyan : Lumina.textLo),
                    ),
                    IconButton(
                      onPressed: c.previous,
                      iconSize: 38,
                      icon: const Icon(Icons.skip_previous_rounded),
                    ),
                    GestureDetector(
                      onTap: c.togglePlay,
                      child: Container(
                        width: 76,
                        height: 76,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: Lumina.gradient,
                          boxShadow: [
                            BoxShadow(color: Lumina.cyan.withAlpha(110), blurRadius: 28),
                          ],
                        ),
                        child: Icon(
                            c.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            size: 44,
                            color: Colors.white),
                      ),
                    ),
                    IconButton(
                      onPressed: c.next,
                      iconSize: 38,
                      icon: const Icon(Icons.skip_next_rounded),
                    ),
                    IconButton(
                      onPressed: c.cycleLoop,
                      icon: Icon(
                        c.loop == LoopMode.one
                            ? Icons.repeat_one_rounded
                            : Icons.repeat_rounded,
                        color: c.loop == LoopMode.off ? Lumina.textLo : Lumina.cyan,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SeekBar extends StatefulWidget {
  final AudioPlayer player;
  const _SeekBar({required this.player});

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  String _fmt(double ms) {
    final d = Duration(milliseconds: ms.round());
    final m = d.inMinutes;
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: widget.player.positionStream,
      builder: (_, snap) {
        final total = (widget.player.duration ?? Duration.zero).inMilliseconds.toDouble();
        final max = total > 0 ? total : 1.0;
        final pos = (snap.data ?? Duration.zero).inMilliseconds.toDouble();
        final value = (_drag ?? pos).clamp(0.0, max).toDouble();
        return Column(
          children: [
            Slider(
              value: value,
              max: max,
              onChanged: (v) => setState(() => _drag = v),
              onChangeEnd: (v) {
                widget.player.seek(Duration(milliseconds: v.round()));
                setState(() => _drag = null);
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_fmt(value),
                      style: const TextStyle(color: Lumina.textLo, fontSize: 12)),
                  Text(_fmt(total),
                      style: const TextStyle(color: Lumina.textLo, fontSize: 12)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
