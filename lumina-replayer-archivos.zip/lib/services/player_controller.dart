import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

class PlayerController extends ChangeNotifier {
  final AudioPlayer player = AudioPlayer();
  final OnAudioQuery _query = OnAudioQuery();

  List<SongModel> songs = [];
  bool loading = true;
  bool permissionDenied = false;
  bool _loaded = false;

  PlayerController() {
    player.currentIndexStream.listen((_) => notifyListeners());
    player.playerStateStream.listen((_) => notifyListeners());
    player.shuffleModeEnabledStream.listen((_) => notifyListeners());
    player.loopModeStream.listen((_) => notifyListeners());
  }

  static String artistOf(SongModel s) =>
      (s.artist == null || s.artist == '<unknown>') ? 'Artista desconocido' : s.artist!;

  SongModel? get current {
    final i = player.currentIndex;
    if (!_loaded || i == null || i < 0 || i >= songs.length) return null;
    return songs[i];
  }

  bool get playing => player.playing;
  bool get shuffle => player.shuffleModeEnabled;
  LoopMode get loop => player.loopMode;

  Future<void> init() async {
    loading = true;
    permissionDenied = false;
    notifyListeners();

    if (!await _requestPermission()) {
      permissionDenied = true;
      loading = false;
      notifyListeners();
      return;
    }

    final all = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    songs = all
        .where((s) => (s.isMusic ?? false) && s.uri != null && (s.duration ?? 0) > 30000)
        .toList();
    _loaded = false;
    loading = false;
    notifyListeners();
  }

  Future<bool> _requestPermission() async {
    if (Platform.isAndroid) {
      if ((await Permission.audio.request()).isGranted) return true;
      return (await Permission.storage.request()).isGranted;
    }
    if (Platform.isIOS) return (await Permission.mediaLibrary.request()).isGranted;
    return false;
  }

  Future<void> openSettings() => openAppSettings();

  Future<void> playFrom(int index) async {
    if (index < 0 || index >= songs.length) return;
    if (!_loaded) {
      final playlist = ConcatenatingAudioSource(
        children: songs
            .map((s) => AudioSource.uri(
                  Uri.parse(s.uri!),
                  tag: MediaItem(
                    id: '${s.id}',
                    title: s.title,
                    artist: artistOf(s),
                    album: s.album,
                    duration: Duration(milliseconds: s.duration ?? 0),
                  ),
                ))
            .toList(),
      );
      await player.setAudioSource(playlist, initialIndex: index);
      _loaded = true;
    } else {
      await player.seek(Duration.zero, index: index);
    }
    player.play();
    notifyListeners();
  }

  void togglePlay() => player.playing ? player.pause() : player.play();

  void next() => player.seekToNext();

  void previous() {
    if (player.position > const Duration(seconds: 3)) {
      player.seek(Duration.zero);
    } else {
      player.seekToPrevious();
    }
  }

  Future<void> toggleShuffle() async {
    final on = !player.shuffleModeEnabled;
    await player.setShuffleModeEnabled(on);
    if (on) await player.shuffle();
  }

  void cycleLoop() {
    const order = [LoopMode.off, LoopMode.all, LoopMode.one];
    player.setLoopMode(order[(order.indexOf(player.loopMode) + 1) % order.length]);
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }
}
