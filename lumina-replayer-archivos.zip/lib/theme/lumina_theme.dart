import 'package:flutter/material.dart';

/// Paleta de Lumina: azul medianoche con destellos cian y violeta.
class Lumina {
  static const night = Color(0xFF060A1C);
  static const deep = Color(0xFF0A1236);
  static const surface = Color(0xFF0E1530);
  static const surfaceHigh = Color(0xFF161F44);

  static const cyan = Color(0xFF5CE1FF);
  static const azure = Color(0xFF4F8CFF);
  static const violet = Color(0xFF7C5CFF);

  static const textHi = Color(0xFFEAF1FF);
  static const textLo = Color(0xFF8E9BC4);

  /// El azul mágico: cian → azul eléctrico → violeta.
  static const gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [cyan, azure, violet],
  );

  static ThemeData get theme {
    final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: night,
      colorScheme: const ColorScheme.dark(
        primary: azure,
        secondary: cyan,
        tertiary: violet,
        surface: surface,
        onSurface: textHi,
      ),
      textTheme: base.textTheme.apply(bodyColor: textHi, displayColor: textHi),
      sliderTheme: SliderThemeData(
        trackHeight: 4,
        activeTrackColor: cyan,
        inactiveTrackColor: surfaceHigh,
        thumbColor: Colors.white,
        overlayColor: cyan.withAlpha(40),
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
      ),
      listTileTheme: const ListTileThemeData(
        iconColor: textLo,
        textColor: textHi,
      ),
    );
  }
}
