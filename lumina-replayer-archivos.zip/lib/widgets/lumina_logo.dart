import 'package:flutter/material.dart';
import '../theme/lumina_theme.dart';

/// Logo: estrella fugaz minimalista.
class LuminaLogo extends StatelessWidget {
  final double size;
  const LuminaLogo({super.key, this.size = 64});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _LogoPainter()),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    final head = Offset(w * .72, h * .28);
    final tip = Offset(w * .10, h * .90);
    const n = Offset(.7071, .7071); // perpendicular a la cola
    final half = w * .045;

    // Cola con degradado que se desvanece
    final a = head + n * half;
    final b = head - n * half;
    final mid = Offset((head.dx + tip.dx) / 2, (head.dy + tip.dy) / 2);
    final tail = Path()
      ..moveTo(a.dx, a.dy)
      ..quadraticBezierTo(mid.dx + w * .05, mid.dy + h * .05, tip.dx, tip.dy)
      ..quadraticBezierTo(mid.dx - w * .05, mid.dy - h * .05, b.dx, b.dy)
      ..close();
    final tailPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [Lumina.cyan, Lumina.azure.withAlpha(150), Lumina.violet.withAlpha(0)],
      ).createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.drawPath(tail, tailPaint);

    // Brillo
    canvas.drawCircle(
      head,
      w * .12,
      Paint()
        ..color = Lumina.cyan.withAlpha(110)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * .06),
    );

    // Destello de 4 puntas
    final r = w * .17, ri = r * .28;
    final star = Path();
    for (var i = 0; i < 8; i++) {
      final ang = i * 3.14159265 / 4 - 3.14159265 / 2;
      final rad = i.isEven ? r : ri;
      final p = Offset(head.dx + rad * _cos(ang), head.dy + rad * _sin(ang));
      i == 0 ? star.moveTo(p.dx, p.dy) : star.lineTo(p.dx, p.dy);
    }
    star.close();
    canvas.drawPath(star, Paint()..color = Colors.white);
  }

  double _cos(double a) => Offset.fromDirection(a).dx;
  double _sin(double a) => Offset.fromDirection(a).dy;

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
