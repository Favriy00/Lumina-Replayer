import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/lumina_theme.dart';

/// Fondo oscuro con resplandores azules y polvo de estrellas.
class MagicBackground extends StatelessWidget {
  final Widget child;
  const MagicBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Lumina.deep, Lumina.night],
            ),
          ),
        ),
        Positioned(top: -140, right: -100, child: _glow(Lumina.azure, 360)),
        Positioned(bottom: -160, left: -120, child: _glow(Lumina.violet, 380)),
        CustomPaint(painter: _StarsPainter()),
        child,
      ],
    );
  }

  Widget _glow(Color c, double size) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [c.withAlpha(70), c.withAlpha(0)]),
          ),
        ),
      );
}

class _StarsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final r = Random(7);
    final p = Paint();
    for (var i = 0; i < 60; i++) {
      p.color = Colors.white.withAlpha(30 + r.nextInt(90));
      canvas.drawCircle(
        Offset(r.nextDouble() * size.width, r.nextDouble() * size.height),
        r.nextDouble() * 1.2 + .3,
        p,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
