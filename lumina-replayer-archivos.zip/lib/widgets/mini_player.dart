import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../screens/now_playing_screen.dart';
import '../services/player_controller.dart';
import '../theme/lumina_theme.dart';
import 'song_artwork.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<PlayerController>();
    final song = c.current;
    if (song == null) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () => Navigator.of(context).push(PageRouteBuilder(
        pageBuilder: (_, __, ___) => const NowPlayingScreen(),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeOutCubic))
              .animate(anim),
          child: child,
        ),
      )),
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        decoration: BoxDecoration(
          color: Lumina.surfaceHigh,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Lumina.azure.withAlpha(90)),
          boxShadow: [BoxShadow(color: Lumina.azure.withAlpha(60), blurRadius: 24)],
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 4, 6),
              child: Row(
                children: [
                  SongArtwork(id: song.id, size: 44, radius: 12),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(song.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(PlayerController.artistOf(song),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Lumina.textLo, fontSize: 12)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: c.togglePlay,
                    icon: Icon(c.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        size: 32, color: Lumina.cyan),
                  ),
                  IconButton(
                    onPressed: c.next,
                    icon: const Icon(Icons.skip_next_rounded, size: 28),
                  ),
                ],
              ),
            ),
            StreamBuilder<Duration>(
              stream: c.player.positionStream,
              builder: (_, snap) {
                final total = c.player.duration?.inMilliseconds ?? 0;
                final pos = snap.data?.inMilliseconds ?? 0;
                return Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      minHeight: 3,
                      value: total > 0 ? (pos / total).clamp(0.0, 1.0) : 0,
                      backgroundColor: Lumina.surface,
                      valueColor: const AlwaysStoppedAnimation(Lumina.cyan),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
