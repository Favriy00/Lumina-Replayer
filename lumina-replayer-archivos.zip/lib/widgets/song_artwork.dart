import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../theme/lumina_theme.dart';

class SongArtwork extends StatelessWidget {
  final int id;
  final double size;
  final double radius;
  const SongArtwork({super.key, required this.id, this.size = 48, this.radius = 12});

  @override
  Widget build(BuildContext context) {
    final border = BorderRadius.circular(radius);
    return QueryArtworkWidget(
      id: id,
      type: ArtworkType.AUDIO,
      size: 600,
      quality: 90,
      artworkWidth: size,
      artworkHeight: size,
      artworkFit: BoxFit.cover,
      artworkBorder: border,
      nullArtworkWidget: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: Lumina.gradient.withOpacity(.35),
          borderRadius: border,
        ),
        child: Icon(Icons.music_note_rounded, color: Colors.white70, size: size * .45),
      ),
    );
  }
}

extension on LinearGradient {
  LinearGradient withOpacity(double o) => LinearGradient(
        begin: begin,
        end: end,
        colors: colors.map((c) => c.withAlpha((255 * o).round())).toList(),
      );
}
